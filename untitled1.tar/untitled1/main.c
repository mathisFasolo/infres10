#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>

#define DELAY 10000

int main(void)
{
    char password[15];
    char age[15];
    char nom[15];
    char prenom[15];
    int pass = 0;
    bool no_filter = false;
    char * fn = "/tmp/XYZ";
    char buffer[60];
    FILE *fp;
    long int  i;

    printf("\n Prenom : \n");
    gets(prenom);
    printf("\n Nom : \n");
    gets(age);
    printf("\n Age : \n");
    gets(nom);
    printf("\n Mot de passe : \n");
    gets(password);

    scanf("%50s", buffer );
    if(!access(fn, W_OK) && no_filter){
        for (int i=0; i < DELAY; i++){
            int a = i * i;
        }
        fp = fopen(fn, "a+");
        fwrite("\n", sizeof(char), 1, fp);
        fwrite(buffer, sizeof(char), strlen(buffer), fp);
        fclose(fp);
    }
    else printf("No permission \n");


    if(strcmp(password, "adelquentin")) {
        printf ("\n Mot de passe faux \n");
    } else {
        printf ("\n Mot de passe juste \n");
        pass = 1;
    }

    if(pass) {
        printf ("\n Root privileges given to the user \n");
    }


    return 0;
}